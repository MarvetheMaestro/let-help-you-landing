import { motion } from "framer-motion";
import { ArrowRight, ShoppingBag, Star, Shield, Truck } from "lucide-react";
import { Link } from "react-router-dom";
import { products } from "../data/products";
import ProductCard from "../components/ProductCard";

export default function Home() {
  const bestSellers = products.filter(p => p.isBestSeller);

  return (
    <div className="overflow-hidden bg-[var(--ka-bone)]">

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-end pb-16 md:pb-24">
        <div className="absolute inset-0 z-0">
          <img
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/62439e52-f271-41ac-8065-70a705617836/hero-banner-1f8d7727-1777307378751.webp"
            alt="Kerenalexis Hero"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--ka-earth)] via-[rgba(44,26,14,0.5)] to-transparent" />
          {/* Adire pattern tint */}
          <div className="absolute inset-0"
            style={{
              backgroundImage: 'repeating-linear-gradient(60deg, rgba(201,168,76,0.04) 0px, rgba(201,168,76,0.04) 1px, transparent 1px, transparent 18px)',
              pointerEvents: 'none'
            }}
          />
        </div>

        <div className="max-w-7xl mx-auto px-6 lg:px-10 relative z-10 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-end">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, ease: [0.25, 0.46, 0.45, 0.94] }}
            >
              <p className="section-label mb-6 text-[var(--ka-gold-light)]">New Collection · 2025</p>
              <h1
                className="hero-text-xl text-[var(--ka-sand)] mb-6 leading-none"
                style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(4rem, 10vw, 8rem)', fontWeight: 300, fontStyle: 'italic' }}
              >
                Boldly<br />
                <em className="not-italic font-semibold text-gold-shimmer">African.</em>
              </h1>
              <p className="text-[var(--ka-sand)] opacity-75 text-base md:text-lg font-light max-w-md mb-10 leading-relaxed" style={{ fontFamily: 'var(--font-body)' }}>
                The fusion of Nigerian heritage and modern luxury — each piece carries a story woven in tradition.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/shop">
                  <button className="btn-ka h-14 px-10 bg-[var(--ka-gold)] text-[var(--ka-earth)] border border-[var(--ka-gold)] flex items-center gap-3 group">
                    <span>Shop Now</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 relative z-10" />
                  </button>
                </Link>
                <Link to="/about">
                  <button className="btn-ka h-14 px-10 border border-[var(--ka-sand)] text-[var(--ka-sand)] flex items-center gap-2">
                    <span>Our Legacy</span>
                  </button>
                </Link>
              </div>
            </motion.div>

            {/* Hero stats */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.9, delay: 0.3 }}
              className="hidden lg:flex justify-end"
            >
              <div className="grid grid-cols-2 gap-px bg-[rgba(201,168,76,0.3)] border border-[rgba(201,168,76,0.3)]">
                {[
                  { num: '2023', label: 'Est. Lagos' },
                  { num: '6+', label: 'Collections' },
                  { num: '100%', label: 'Handcrafted' },
                  { num: '🇳🇬', label: 'Nigerian Pride' },
                ].map(({ num, label }) => (
                  <div key={label} className="bg-[rgba(44,26,14,0.7)] px-8 py-6 backdrop-blur-sm text-center">
                    <p className="text-[var(--ka-gold)] text-2xl font-display font-semibold" style={{ fontFamily: 'var(--font-display)' }}>{num}</p>
                    <p className="text-[var(--ka-sand)] opacity-60 text-[10px] tracking-widest uppercase mt-1" style={{ fontFamily: 'var(--font-narrow)' }}>{label}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2">
          <div className="w-px h-12 bg-gradient-to-b from-[var(--ka-gold)] to-transparent animate-pulse" />
        </div>
      </section>

      {/* ── MARQUEE BAND ── */}
      <div className="bg-[var(--ka-earth)] py-4 overflow-hidden">
        <div className="marquee-track">
          {Array(10).fill(null).map((_, i) => (
            <span key={i} className="flex items-center gap-8 px-8 text-[11px] tracking-[0.22em] uppercase font-narrow text-[var(--ka-sand)] opacity-70 whitespace-nowrap">
              <span>Nigerian Luxury</span>
              <span className="text-[var(--ka-gold)]">◆</span>
              <span>Afro Couture</span>
              <span className="text-[var(--ka-gold)]">◆</span>
              <span>Heritage Craftsmanship</span>
              <span className="text-[var(--ka-gold)]">◆</span>
              <span>Modern Minimalism</span>
              <span className="text-[var(--ka-gold)]">◆</span>
            </span>
          ))}
        </div>
      </div>

      {/* ── FEATURED COLLECTIONS ── */}
      <section className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-4">
            <div>
              <p className="section-label mb-3">Curated for You</p>
              <h2 className="text-5xl md:text-6xl" style={{ fontFamily: 'var(--font-display)', fontWeight: 300 }}>
                Our <em>Collections</em>
              </h2>
            </div>
            <Link to="/shop" className="ka-underline section-label text-[var(--ka-earth)] flex items-center gap-2 self-end md:self-auto">
              View All <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              {
                title: 'Luxury',
                subtitle: 'Refined Heritage',
                img: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/62439e52-f271-41ac-8065-70a705617836/luxury-collection-42a1d423-1777307379192.webp',
                link: '/shop?category=Luxury',
                size: 'md:row-span-2'
              },
              {
                title: 'Streetwear',
                subtitle: 'Lagos Energy',
                img: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/62439e52-f271-41ac-8065-70a705617836/streetwear-collection-72734d27-1777307379467.webp',
                link: '/shop?category=Streetwear',
                size: ''
              },
              {
                title: 'Minimalist',
                subtitle: 'Clean Elegance',
                img: 'https://storage.googleapis.com/dala-prod-public-storage/generated-images/62439e52-f271-41ac-8065-70a705617836/minimalist-collection-8c3ecd70-1777307379048.webp',
                link: '/shop?category=Minimalist',
                size: ''
              }
            ].map((col, idx) => (
              <motion.div
                key={idx}
                whileHover={{ scale: 1.01 }}
                transition={{ duration: 0.4 }}
                className={`relative overflow-hidden group cursor-pointer ${col.size} ${idx === 0 ? 'aspect-[3/4] md:aspect-auto' : 'aspect-[4/3]'}`}
              >
                <Link to={col.link} className="block w-full h-full">
                  <img
                    src={col.img}
                    alt={col.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[rgba(44,26,14,0.85)] via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 p-6 md:p-8">
                    <p className="text-[var(--ka-gold)] text-[10px] tracking-[0.3em] uppercase font-narrow font-semibold mb-1">{col.subtitle}</p>
                    <h3 className="text-[var(--ka-sand)] text-3xl md:text-4xl font-display mb-3" style={{ fontFamily: 'var(--font-display)', fontWeight: 300 }}>{col.title}</h3>
                    <span className="inline-flex items-center gap-2 text-[var(--ka-sand)] text-[11px] tracking-[0.22em] uppercase font-narrow border-b border-[var(--ka-gold)] pb-0.5 opacity-80 group-hover:opacity-100 group-hover:text-[var(--ka-gold)] transition-all">
                      Explore <ArrowRight className="h-3 w-3" />
                    </span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── BEST SELLERS ── */}
      <section className="py-24 ka-pattern-overlay bg-[var(--ka-sand)]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="text-center mb-16">
            <p className="section-label mb-4">Customer Favourites</p>
            <h2 className="text-5xl md:text-6xl text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-display)', fontWeight: 300 }}>
              Best <em>Sellers</em>
            </h2>
            <div className="adinkra-divider mt-6 max-w-xs mx-auto">
              <span className="text-[var(--ka-gold)] text-xl">✦</span>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {bestSellers.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="text-center mt-14">
            <Link to="/shop">
              <button className="btn-ka h-13 px-12 py-4 border border-[var(--ka-earth)] text-[var(--ka-earth)] hover:text-[var(--ka-earth)] flex items-center gap-3 mx-auto">
                <span>View Full Collection</span>
                <ArrowRight className="h-4 w-4 relative z-10" />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* ── BRAND STORY ── */}
      <section className="bg-[var(--ka-earth)] text-[var(--ka-sand)] py-24 md:py-36 ka-pattern-overlay">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/62439e52-f271-41ac-8065-70a705617836/lifestyle-social-proof-798f0489-1777307379655.webp"
                alt="Brand Story"
                className="w-full aspect-square object-cover"
              />
              {/* Gold corner accent */}
              <div className="absolute -top-3 -left-3 w-16 h-16 border-t-2 border-l-2 border-[var(--ka-gold)]" />
              <div className="absolute -bottom-3 -right-3 w-16 h-16 border-b-2 border-r-2 border-[var(--ka-gold)]" />
              <div className="absolute bottom-6 right-6 bg-[var(--ka-gold)] text-[var(--ka-earth)] px-5 py-3">
                <p className="text-3xl font-display italic" style={{ fontFamily: 'var(--font-display)' }}>Est. 2023</p>
              </div>
            </div>

            <div className="space-y-8">
              <p className="section-label text-[var(--ka-gold-light)]">Our Heritage</p>
              <h2 className="text-4xl md:text-5xl lg:text-6xl leading-tight" style={{ fontFamily: 'var(--font-display)', fontWeight: 300 }}>
                Crafting Nigerian Luxury for the <em>Modern World</em>
              </h2>
              <div className="gold-border-left border-[var(--ka-gold)]">
                <p className="text-[var(--ka-sand)] opacity-70 text-lg leading-relaxed">
                  Kerenalexis was born from a desire to celebrate the rich textile heritage of Nigeria
                  while embracing the global language of luxury fashion. Each piece is a conversation
                  between tradition and modernity.
                </p>
              </div>
              <Link to="/about" className="inline-flex items-center gap-3 text-[var(--ka-gold)] font-narrow text-sm tracking-widest uppercase border-b border-[var(--ka-gold)] pb-1 hover:opacity-80 transition-opacity">
                Learn Our Journey <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── TRUST SIGNALS ── */}
      <section className="py-20 border-b border-[var(--ka-sand)]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-[var(--ka-sand)]">
            {[
              { icon: Truck, title: 'Global Shipping', desc: 'Fast delivery across Nigeria and worldwide', detail: '3–7 business days' },
              { icon: Shield, title: 'Secure Payment', desc: 'Safe checkout powered by Paystack', detail: 'All Nigerian cards accepted' },
              { icon: Star, title: 'Premium Quality', desc: 'Hand-selected materials for lasting elegance', detail: 'Artisan-crafted in Lagos' },
            ].map(({ icon: Icon, title, desc, detail }) => (
              <div key={title} className="flex flex-col items-center text-center py-10 px-8 gap-4 group">
                <div className="w-14 h-14 border border-[var(--ka-gold)] flex items-center justify-center group-hover:bg-[var(--ka-gold)] transition-colors duration-300">
                  <Icon className="h-6 w-6 text-[var(--ka-gold)] group-hover:text-[var(--ka-earth)] transition-colors duration-300" strokeWidth={1.5} />
                </div>
                <h3 className="font-display text-xl" style={{ fontFamily: 'var(--font-display)' }}>{title}</h3>
                <p className="text-[var(--ka-smoke)] text-sm leading-relaxed">{desc}</p>
                <p className="section-label text-[var(--ka-earth)] opacity-50">{detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
