import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import { Eye, EyeOff, ArrowRight } from 'lucide-react';

export default function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName } },
      });
      if (error) throw error;
      if (data?.user?.identities?.length === 0) {
        toast.error('Account already exists');
      } else {
        toast.success('Welcome! Please verify your email.');
        navigate('/login');
      }
    } catch (error: any) {
      toast.error(error.message || 'Error signing up');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="hidden lg:block relative">
        <img
          src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/62439e52-f271-41ac-8065-70a705617836/luxury-collection-42a1d423-1777307379192.webp"
          alt="Kerenalexis Luxury"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[rgba(44,26,14,0.6)]" />
        <div className="absolute bottom-12 left-10 text-[var(--ka-sand)]">
          <p className="section-label text-[var(--ka-gold)] mb-3">Join Us</p>
          <p className="text-4xl leading-snug" style={{ fontFamily: 'var(--font-display)', fontWeight: 300, fontStyle: 'italic' }}>
            Be Part of<br/>The Legacy
          </p>
        </div>
      </div>

      <div className="flex flex-col items-center justify-center bg-[var(--ka-bone)] px-8 py-16">
        <div className="w-full max-w-sm">
          <Link to="/" className="block text-center mb-12">
            <span className="text-3xl tracking-wider" style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 300 }}>
              Keren<span className="text-[var(--ka-gold)] font-semibold not-italic">alexis</span>
            </span>
          </Link>

          <h1 className="text-4xl text-[var(--ka-earth)] mb-2" style={{ fontFamily: 'var(--font-display)', fontWeight: 300 }}>Join Kerenalexis</h1>
          <p className="text-[var(--ka-smoke)] text-sm mb-10" style={{ fontFamily: 'var(--font-body)' }}>Experience Nigerian luxury fashion</p>

          <form onSubmit={handleSignup} className="space-y-6">
            {[
              { label: 'Full Name', type: 'text', value: fullName, setValue: setFullName, placeholder: 'Amara Okonkwo' },
              { label: 'Email Address', type: 'email', value: email, setValue: setEmail, placeholder: 'you@example.com' },
            ].map(({ label, type, value, setValue, placeholder }) => (
              <div key={label} className="space-y-2">
                <label className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-narrow)' }}>{label}</label>
                <input
                  type={type}
                  required
                  value={value}
                  onChange={e => setValue(e.target.value)}
                  placeholder={placeholder}
                  className="w-full border-b border-[var(--ka-earth)] bg-transparent px-0 py-3 text-[var(--ka-earth)] placeholder:text-[var(--ka-smoke)] placeholder:opacity-40 focus:outline-none focus:border-[var(--ka-gold)] transition-colors text-sm"
                  style={{ fontFamily: 'var(--font-body)' }}
                />
              </div>
            ))}

            <div className="space-y-2">
              <label className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-narrow)' }}>Password</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Min. 8 characters"
                  minLength={8}
                  className="w-full border-b border-[var(--ka-earth)] bg-transparent px-0 py-3 pr-8 text-[var(--ka-earth)] placeholder:text-[var(--ka-smoke)] placeholder:opacity-40 focus:outline-none focus:border-[var(--ka-gold)] transition-colors text-sm"
                  style={{ fontFamily: 'var(--font-body)' }}
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-0 bottom-3 text-[var(--ka-smoke)] hover:text-[var(--ka-earth)] transition-colors">
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-ka w-full py-4 bg-[var(--ka-earth)] text-[var(--ka-gold)] border border-[var(--ka-earth)] flex items-center justify-center gap-3 mt-4 disabled:opacity-50"
            >
              <span>{loading ? 'Creating Account…' : 'Create Account'}</span>
              {!loading && <ArrowRight className="h-4 w-4 relative z-10" />}
            </button>
          </form>

          <p className="text-center text-sm text-[var(--ka-smoke)] mt-8" style={{ fontFamily: 'var(--font-body)' }}>
            Already a member?{' '}
            <Link to="/login" className="text-[var(--ka-earth)] font-semibold ka-underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
