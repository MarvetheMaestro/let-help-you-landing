import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { Plus, Trash2, Edit2, X, Package, BarChart3, ShoppingBag, Users, LogOut, Home, Settings, Star } from 'lucide-react';
import { products as staticProducts, Product } from '@/data/products';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

const CATEGORIES = ['Streetwear', 'Luxury', 'Minimalist', 'Accessories'] as const;

const blankProduct: Partial<Product> = {
  name: '', price: 0, category: 'Minimalist', image: '', description: '',
  isBestSeller: false, sizes: ['S', 'M', 'L']
};

export default function ProductManagement() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [current, setCurrent] = useState<Partial<Product>>(blankProduct);
  const [activeTab, setActiveTab] = useState<'products' | 'stats'>('products');
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      // TODO: Replace with real Supabase fetch:
      // const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
      // if (error) throw error;
      // setProducts(data);
      setProducts(staticProducts);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isEditing) {
        // await supabase.from('products').update(current).eq('id', current.id);
        setProducts(products.map(p => p.id === current.id ? (current as Product) : p));
        toast.success('Product updated');
      } else {
        const newProduct = { ...current, id: crypto.randomUUID().slice(0, 9) } as Product;
        // await supabase.from('products').insert(newProduct);
        setProducts([newProduct, ...products]);
        toast.success('Product added');
      }
      setShowForm(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this product?')) return;
    // await supabase.from('products').delete().eq('id', id);
    setProducts(products.filter(p => p.id !== id));
    toast.success('Product deleted');
  };

  const handleEdit = (product: Product) => {
    setCurrent(product);
    setIsEditing(true);
    setShowForm(true);
  };

  const resetForm = () => {
    setCurrent(blankProduct);
    setIsEditing(false);
  };

  const stats = [
    { label: 'Total Products', value: products.length, icon: Package, color: 'var(--ka-gold)' },
    { label: 'Best Sellers', value: products.filter(p => p.isBestSeller).length, icon: Star, color: '#C9A84C' },
    { label: 'Collections', value: CATEGORIES.length, icon: BarChart3, color: 'var(--ka-clay)' },
    { label: 'Avg Price', value: `$${Math.round(products.reduce((s,p)=>s+p.price,0)/Math.max(products.length,1))}`, icon: ShoppingBag, color: 'var(--ka-earth)' },
  ];

  return (
    <div className="flex min-h-screen bg-[var(--ka-bone)]" style={{ fontFamily: 'var(--font-body)' }}>

      {/* ── SIDEBAR ── */}
      <aside className="admin-sidebar w-64 hidden md:flex flex-col fixed left-0 top-0 bottom-0 z-50">
        <div className="p-6 border-b border-[rgba(201,168,76,0.2)]">
          <Link to="/" className="block">
            <p className="text-2xl tracking-wide text-[var(--ka-sand)]" style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontWeight: 300 }}>
              Keren<span className="text-[var(--ka-gold)] font-semibold not-italic">alexis</span>
            </p>
            <p className="text-[9px] tracking-[0.3em] uppercase text-[var(--ka-gold)] opacity-60 mt-0.5" style={{ fontFamily: 'var(--font-narrow)' }}>Admin Dashboard</p>
          </Link>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { icon: BarChart3, label: 'Overview', tab: 'stats' as const },
            { icon: Package, label: 'Products', tab: 'products' as const },
          ].map(({ icon: Icon, label, tab }) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm tracking-wide transition-all ${
                activeTab === tab
                  ? 'bg-[var(--ka-gold)] text-[var(--ka-earth)] font-semibold'
                  : 'text-[var(--ka-sand)] opacity-60 hover:opacity-100 hover:bg-[rgba(201,168,76,0.1)]'
              }`}
              style={{ fontFamily: 'var(--font-narrow)' }}
            >
              <Icon className="h-4 w-4" />
              {label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-[rgba(201,168,76,0.2)] space-y-2">
          <Link to="/" className="w-full flex items-center gap-3 px-4 py-3 text-sm text-[var(--ka-sand)] opacity-60 hover:opacity-100 transition-opacity" style={{ fontFamily: 'var(--font-narrow)' }}>
            <Home className="h-4 w-4" />
            View Site
          </Link>
          <button
            onClick={() => { signOut(); navigate('/'); }}
            className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-400 opacity-70 hover:opacity-100 transition-opacity"
            style={{ fontFamily: 'var(--font-narrow)' }}
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </button>
          {user && (
            <p className="px-4 text-[10px] text-[var(--ka-sand)] opacity-30 truncate">{user.email}</p>
          )}
        </div>
      </aside>

      {/* ── MAIN CONTENT ── */}
      <div className="flex-1 md:ml-64">

        {/* Top header */}
        <div className="bg-white border-b border-[var(--ka-sand)] px-8 py-5 flex items-center justify-between sticky top-0 z-40">
          <div>
            <h1 className="text-2xl text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-display)', fontWeight: 400 }}>
              {activeTab === 'products' ? 'Product Management' : 'Overview'}
            </h1>
            <p className="text-xs text-[var(--ka-smoke)] tracking-widest uppercase mt-0.5" style={{ fontFamily: 'var(--font-narrow)' }}>
              Kerenalexis Admin
            </p>
          </div>
          {activeTab === 'products' && (
            <button
              onClick={() => { resetForm(); setShowForm(true); }}
              className="btn-ka flex items-center gap-2 px-6 py-3 bg-[var(--ka-earth)] text-[var(--ka-gold)] border border-[var(--ka-earth)] text-sm"
            >
              <Plus className="h-4 w-4 relative z-10" />
              <span>Add Product</span>
            </button>
          )}
        </div>

        <div className="p-8">

          {/* Stats Tab */}
          {activeTab === 'stats' && (
            <div className="space-y-8">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {stats.map(({ label, value, icon: Icon, color }) => (
                  <div key={label} className="bg-white border border-[var(--ka-sand)] p-6">
                    <div className="flex items-center justify-between mb-3">
                      <Icon className="h-5 w-5" style={{ color }} />
                      <span className="text-[9px] tracking-widest uppercase text-[var(--ka-smoke)]" style={{ fontFamily: 'var(--font-narrow)' }}>{label}</span>
                    </div>
                    <p className="text-3xl font-display text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-display)' }}>{value}</p>
                  </div>
                ))}
              </div>

              <div className="bg-white border border-[var(--ka-sand)] p-6">
                <h2 className="text-xl mb-4 text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-display)' }}>Category Breakdown</h2>
                {CATEGORIES.map(cat => {
                  const count = products.filter(p => p.category === cat).length;
                  const pct = products.length ? Math.round((count / products.length) * 100) : 0;
                  return (
                    <div key={cat} className="flex items-center gap-4 mb-4">
                      <span className="text-xs tracking-widest uppercase w-24 text-[var(--ka-smoke)]" style={{ fontFamily: 'var(--font-narrow)' }}>{cat}</span>
                      <div className="flex-1 bg-[var(--ka-sand)] h-2">
                        <div className="h-2 bg-[var(--ka-gold)] transition-all" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-[var(--ka-smoke)] w-8 text-right">{count}</span>
                    </div>
                  );
                })}
              </div>

              {/* Backend Setup Guide */}
              <div className="bg-[var(--ka-earth)] text-[var(--ka-sand)] p-8 ka-pattern-overlay">
                <div className="flex items-center gap-3 mb-4">
                  <Settings className="h-5 w-5 text-[var(--ka-gold)]" />
                  <h2 className="text-xl text-[var(--ka-gold)]" style={{ fontFamily: 'var(--font-display)' }}>Supabase Backend Setup</h2>
                </div>
                <p className="text-sm opacity-70 mb-6 leading-relaxed">Follow these steps to connect your admin dashboard to a real database so product changes persist.</p>
                <div className="space-y-4">
                  {[
                    { step: '1', title: 'Create products table', code: `CREATE TABLE products (\n  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,\n  name TEXT NOT NULL,\n  price NUMERIC NOT NULL,\n  category TEXT CHECK (category IN ('Luxury','Streetwear','Minimalist','Accessories')),\n  image TEXT,\n  description TEXT,\n  is_best_seller BOOLEAN DEFAULT false,\n  sizes TEXT[] DEFAULT ARRAY['S','M','L'],\n  created_at TIMESTAMPTZ DEFAULT NOW()\n);` },
                    { step: '2', title: 'Enable Row Level Security', code: `ALTER TABLE products ENABLE ROW LEVEL SECURITY;\n-- Allow public reads\nCREATE POLICY "Public read" ON products FOR SELECT USING (true);\n-- Allow admin writes (authenticated)\nCREATE POLICY "Admin write" ON products FOR ALL\n  USING (auth.role() = 'authenticated');` },
                    { step: '3', title: 'Uncomment Supabase calls in this file', code: `// In fetchProducts():\nconst { data, error } = await supabase.from('products').select('*');\n\n// In handleSubmit():\nawait supabase.from('products').upsert(current);\n\n// In handleDelete():\nawait supabase.from('products').delete().eq('id', id);` },
                  ].map(({ step, title, code }) => (
                    <div key={step} className="border border-[rgba(201,168,76,0.2)] p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <span className="w-6 h-6 bg-[var(--ka-gold)] text-[var(--ka-earth)] text-xs font-bold flex items-center justify-center">{step}</span>
                        <span className="text-sm font-semibold text-[var(--ka-gold-light)]" style={{ fontFamily: 'var(--font-narrow)' }}>{title}</span>
                      </div>
                      <pre className="text-[11px] text-[var(--ka-sand)] opacity-60 font-mono bg-black/20 p-3 overflow-x-auto leading-relaxed whitespace-pre-wrap">{code}</pre>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Products Tab */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              {/* Add/Edit Form */}
              {showForm && (
                <div className="bg-white border border-[var(--ka-sand)] p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-display)' }}>
                      {isEditing ? 'Edit Product' : 'Add New Product'}
                    </h2>
                    <button onClick={() => { setShowForm(false); resetForm(); }} className="text-[var(--ka-smoke)] hover:text-[var(--ka-earth)] transition-colors">
                      <X className="h-5 w-5" />
                    </button>
                  </div>

                  <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      { label: 'Product Name', key: 'name', type: 'text', placeholder: 'Royal Silk Fusion Robe' },
                      { label: 'Price ($)', key: 'price', type: 'number', placeholder: '450' },
                      { label: 'Image URL', key: 'image', type: 'text', placeholder: 'https://...' },
                    ].map(({ label, key, type, placeholder }) => (
                      <div key={key} className="space-y-2">
                        <label className="text-[10px] tracking-widest uppercase font-semibold text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-narrow)' }}>{label}</label>
                        <input
                          type={type}
                          placeholder={placeholder}
                          value={(current as any)[key]}
                          onChange={e => setCurrent({ ...current, [key]: type === 'number' ? parseFloat(e.target.value) : e.target.value })}
                          required
                          className="w-full border border-[var(--ka-sand)] px-4 py-3 text-sm text-[var(--ka-earth)] focus:outline-none focus:border-[var(--ka-gold)] transition-colors bg-[var(--ka-bone)]"
                          style={{ fontFamily: 'var(--font-body)' }}
                        />
                      </div>
                    ))}

                    <div className="space-y-2">
                      <label className="text-[10px] tracking-widest uppercase font-semibold text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-narrow)' }}>Category</label>
                      <select
                        value={current.category}
                        onChange={e => setCurrent({ ...current, category: e.target.value as any })}
                        className="w-full border border-[var(--ka-sand)] px-4 py-3 text-sm text-[var(--ka-earth)] focus:outline-none focus:border-[var(--ka-gold)] bg-[var(--ka-bone)]"
                        style={{ fontFamily: 'var(--font-body)' }}
                      >
                        {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>

                    <div className="md:col-span-2 space-y-2">
                      <label className="text-[10px] tracking-widest uppercase font-semibold text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-narrow)' }}>Description</label>
                      <textarea
                        rows={3}
                        value={current.description}
                        onChange={e => setCurrent({ ...current, description: e.target.value })}
                        required
                        className="w-full border border-[var(--ka-sand)] px-4 py-3 text-sm text-[var(--ka-earth)] focus:outline-none focus:border-[var(--ka-gold)] transition-colors bg-[var(--ka-bone)] resize-none"
                        style={{ fontFamily: 'var(--font-body)' }}
                      />
                    </div>

                    <div className="md:col-span-2 flex items-center gap-3">
                      <input
                        type="checkbox"
                        id="bestSeller"
                        checked={current.isBestSeller}
                        onChange={e => setCurrent({ ...current, isBestSeller: e.target.checked })}
                        className="w-4 h-4 accent-[var(--ka-gold)]"
                      />
                      <label htmlFor="bestSeller" className="text-sm text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-narrow)' }}>
                        Mark as Best Seller
                      </label>
                    </div>

                    <div className="md:col-span-2 flex gap-4 pt-2">
                      <button type="submit" className="btn-ka flex items-center gap-2 px-8 py-3 bg-[var(--ka-earth)] text-[var(--ka-gold)] border border-[var(--ka-earth)] text-sm">
                        <span>{isEditing ? 'Update Product' : 'Add Product'}</span>
                      </button>
                      <button type="button" onClick={() => { setShowForm(false); resetForm(); }}
                        className="btn-ka px-8 py-3 border border-[var(--ka-sand)] text-[var(--ka-smoke)] text-sm">
                        <span>Cancel</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Products grid */}
              {loading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="w-8 h-8 border-2 border-[var(--ka-gold)] border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <div className="bg-white border border-[var(--ka-sand)]">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-[var(--ka-sand)] bg-[var(--ka-bone)]">
                          {['Image', 'Name', 'Category', 'Price', 'Best Seller', 'Actions'].map(h => (
                            <th key={h} className="px-6 py-4 text-left text-[10px] tracking-widest uppercase text-[var(--ka-smoke)]" style={{ fontFamily: 'var(--font-narrow)' }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {products.map((product, i) => (
                          <tr key={product.id} className={`border-b border-[var(--ka-sand)] hover:bg-[var(--ka-bone)] transition-colors ${i % 2 === 0 ? '' : 'bg-[rgba(245,236,215,0.3)]'}`}>
                            <td className="px-6 py-4">
                              <img src={product.image} alt={product.name} className="h-14 w-14 object-cover" />
                            </td>
                            <td className="px-6 py-4">
                              <p className="font-medium text-[var(--ka-earth)]" style={{ fontFamily: 'var(--font-display)' }}>{product.name}</p>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-[10px] tracking-widest uppercase bg-[var(--ka-sand)] text-[var(--ka-earth)] px-2 py-1" style={{ fontFamily: 'var(--font-narrow)' }}>
                                {product.category}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-[var(--ka-clay)] font-display" style={{ fontFamily: 'var(--font-display)' }}>
                              ${product.price}
                            </td>
                            <td className="px-6 py-4">
                              {product.isBestSeller
                                ? <span className="text-[var(--ka-gold)]"><Star className="h-4 w-4 fill-current" /></span>
                                : <span className="text-[var(--ka-sand)]">—</span>
                              }
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => handleEdit(product)}
                                  className="p-2 border border-[var(--ka-sand)] hover:border-[var(--ka-gold)] hover:text-[var(--ka-gold)] transition-colors text-[var(--ka-smoke)]"
                                >
                                  <Edit2 className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  onClick={() => handleDelete(product.id)}
                                  className="p-2 border border-[var(--ka-sand)] hover:border-red-300 hover:text-red-500 transition-colors text-[var(--ka-smoke)]"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
