import { Link } from 'react-router-dom';
import { Product } from '@/data/products';
import { motion } from 'framer-motion';
import { ShoppingBag, Eye } from 'lucide-react';
import { useCart } from '@/context/CartContext';

const ProductCard = ({ product }: { product: Product }) => {
  const { addToCart } = useCart();

  return (
    <motion.div
      className="group ka-lift"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      {/* Image */}
      <div className="product-image-container mb-4 relative overflow-hidden bg-[var(--ka-sand)]">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        </Link>

        {/* Best Seller badge */}
        {product.isBestSeller && (
          <span className="absolute top-4 left-0 bg-[var(--ka-gold)] text-[var(--ka-earth)] px-3 py-1 text-[9px] font-narrow font-bold tracking-[0.25em] uppercase">
            Best Seller
          </span>
        )}

        {/* Category badge */}
        <span className="absolute top-4 right-4 bg-[var(--ka-earth)] text-[var(--ka-sand)] px-2 py-0.5 text-[9px] font-narrow tracking-[0.2em] uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          {product.category}
        </span>

        {/* Hover overlay with actions */}
        <div className="absolute inset-0 bg-[rgba(44,26,14,0.4)] opacity-0 group-hover:opacity-100 transition-opacity duration-400 flex flex-col items-center justify-end pb-0">
          <button
            onClick={(e) => {
              e.preventDefault();
              addToCart(product, product.sizes[0]);
            }}
            className="w-full py-4 bg-[var(--ka-earth)] text-[var(--ka-gold)] translate-y-full group-hover:translate-y-0 transition-transform duration-400 text-[10px] font-narrow font-semibold tracking-[0.25em] uppercase flex items-center justify-center gap-2 hover:bg-[var(--ka-gold)] hover:text-[var(--ka-earth)]"
            style={{ transitionDelay: '0.05s' }}
          >
            <ShoppingBag className="h-4 w-4" /> Quick Add
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="space-y-1 px-1">
        <div className="flex justify-between items-baseline gap-2">
          <Link to={`/product/${product.id}`}>
            <h3
              className="text-base leading-snug hover:text-[var(--ka-clay)] transition-colors ka-underline"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 400 }}
            >
              {product.name}
            </h3>
          </Link>
          <span
            className="text-base font-light text-[var(--ka-clay)] whitespace-nowrap"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            ${product.price}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-[10px] text-[var(--ka-smoke)] font-narrow tracking-[0.22em] uppercase">{product.category}</p>
          <div className="flex gap-1">
            {product.sizes.slice(0, 3).map(s => (
              <span key={s} className="text-[9px] text-[var(--ka-smoke)] border border-[var(--ka-sand)] px-1">{s}</span>
            ))}
            {product.sizes.length > 3 && <span className="text-[9px] text-[var(--ka-smoke)]">+{product.sizes.length - 3}</span>}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
