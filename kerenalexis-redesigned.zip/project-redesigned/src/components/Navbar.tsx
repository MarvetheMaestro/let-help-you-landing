import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { ShoppingBag, User, LogOut, Menu, X, Settings, ChevronDown } from 'lucide-react';
import { useState, useEffect } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Navbar() {
  const { totalItems } = useCart();
  const { user, signOut } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const isHome = location.pathname === '/';

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const navBase = isHome && !scrolled
    ? 'bg-transparent text-white'
    : 'bg-[var(--ka-bone)] text-[var(--ka-earth)] shadow-sm';

  return (
    <>
      {/* Top marquee strip */}
      <div className="fixed top-0 left-0 right-0 z-[60] bg-[var(--ka-earth)] text-[var(--ka-gold)] overflow-hidden h-7 flex items-center">
        <div className="marquee-track">
          {Array(8).fill(null).map((_, i) => (
            <span key={i} className="flex items-center gap-6 px-8 text-[10px] font-narrow font-semibold tracking-[0.25em] uppercase whitespace-nowrap">
              <span>Free Shipping Across Nigeria</span>
              <span className="text-[var(--ka-gold-dark)]">✦</span>
              <span>Handcrafted Nigerian Luxury</span>
              <span className="text-[var(--ka-gold-dark)]">✦</span>
              <span>New Collection 2025</span>
              <span className="text-[var(--ka-gold-dark)]">✦</span>
            </span>
          ))}
        </div>
      </div>

      <nav className={`fixed top-7 left-0 right-0 z-50 transition-all duration-500 ${navBase}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="flex justify-between items-center h-16 md:h-20">

            {/* Left nav */}
            <div className="hidden md:flex items-center gap-10">
              {[['Shop', '/shop'], ['Collections', '/shop'], ['About', '/about']].map(([label, path]) => (
                <Link
                  key={label}
                  to={path}
                  className="ka-underline text-[11px] font-semibold tracking-[0.2em] uppercase font-narrow transition-opacity hover:opacity-70"
                >
                  {label}
                </Link>
              ))}
            </div>

            {/* Center logo */}
            <Link to="/" className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center leading-none group">
              <span
                className="font-display text-2xl md:text-3xl tracking-[0.15em] uppercase font-semibold transition-all duration-300"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Keren<span className="text-[var(--ka-gold)]">alexis</span>
              </span>
              <span className="text-[8px] tracking-[0.4em] uppercase font-narrow opacity-60 mt-0.5">Lagos · Nigeria</span>
            </Link>

            {/* Right actions */}
            <div className="flex items-center gap-5 md:gap-7">
              <Link
                to="/contact"
                className="hidden md:block ka-underline text-[11px] font-semibold tracking-[0.2em] uppercase font-narrow transition-opacity hover:opacity-70"
              >
                Concierge
              </Link>

              {/* Cart */}
              <Link to="/checkout" className="relative group">
                <ShoppingBag className="h-5 w-5 transition-transform group-hover:scale-110" strokeWidth={1.5} />
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[var(--ka-gold)] text-[var(--ka-earth)] text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center leading-none">
                    {totalItems}
                  </span>
                )}
              </Link>

              {/* User */}
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-1 hover:opacity-70 transition-opacity">
                      <User className="h-5 w-5" strokeWidth={1.5} />
                      <ChevronDown className="h-3 w-3" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-52 rounded-none border-[var(--ka-earth)] bg-[var(--ka-bone)]">
                    <div className="px-3 py-2 text-[10px] tracking-widest uppercase text-[var(--ka-smoke)] border-b border-[var(--ka-sand)] mb-1">
                      {user.email}
                    </div>
                    <DropdownMenuItem onClick={() => navigate('/admin')} className="rounded-none text-xs tracking-widest uppercase cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Manage Products</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleSignOut} className="rounded-none text-xs tracking-widest uppercase text-red-700 cursor-pointer">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Sign Out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link to="/login" className="ka-underline text-[11px] font-semibold tracking-[0.2em] uppercase font-narrow hidden md:block transition-opacity hover:opacity-70">
                  Sign In
                </Link>
              )}

              {/* Mobile toggle */}
              <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
                {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Gold accent line */}
        <div className={`h-px transition-all duration-500 ${scrolled || !isHome ? 'bg-gradient-to-r from-transparent via-[var(--ka-gold)] to-transparent opacity-40' : 'opacity-0'}`} />
      </nav>

      {/* Mobile drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-40 pt-28 bg-[var(--ka-earth)] text-[var(--ka-sand)]">
          <div className="flex flex-col items-center justify-center h-full gap-10">
            {[['Shop', '/shop'], ['Collections', '/shop'], ['About', '/about'], ['Concierge', '/contact']].map(([label, path]) => (
              <Link
                key={label}
                to={path}
                onClick={() => setIsOpen(false)}
                className="font-display text-5xl italic tracking-wide hover:text-[var(--ka-gold)] transition-colors"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {label}
              </Link>
            ))}
            {user ? (
              <>
                <Link to="/admin" onClick={() => setIsOpen(false)} className="section-label mt-4">Admin Panel</Link>
                <button onClick={() => { handleSignOut(); setIsOpen(false); }} className="section-label text-red-400">Sign Out</button>
              </>
            ) : (
              <Link to="/login" onClick={() => setIsOpen(false)} className="section-label mt-4">Sign In</Link>
            )}
          </div>
        </div>
      )}
    </>
  );
}
