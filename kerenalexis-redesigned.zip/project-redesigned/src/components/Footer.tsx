import { Link } from 'react-router-dom';
import { Mail, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[var(--ka-earth)] text-[var(--ka-sand)] ka-pattern-overlay">
      {/* Top gold line */}
      <div className="h-px bg-gradient-to-r from-transparent via-[var(--ka-gold)] to-transparent" />

      <div className="max-w-7xl mx-auto px-6 lg:px-10 pt-20 pb-10">
        {/* Main grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-14 mb-16">

          {/* Brand */}
          <div className="lg:col-span-1 space-y-6">
            <div>
              <h2
                className="text-3xl tracking-wider uppercase"
                style={{ fontFamily: 'var(--font-display)', fontWeight: 300, fontStyle: 'italic' }}
              >
                Keren<span className="text-gold-shimmer font-semibold not-italic">alexis</span>
              </h2>
              <p className="text-[10px] tracking-[0.35em] uppercase font-narrow text-[var(--ka-gold)] opacity-70 mt-1">Lagos · Nigeria · Est. 2023</p>
            </div>
            <p className="text-[var(--ka-sand)] opacity-60 text-sm leading-relaxed max-w-xs">
              Premium fashion from the heart of Nigeria. We blend heritage with modern minimalism to create timeless pieces for the bold.
            </p>
            <div className="flex gap-5 items-center">
              {[
                { Icon: Instagram, href: '#' },
                { Icon: Facebook, href: '#' },
                { Icon: Twitter, href: '#' },
              ].map(({ Icon, href }, i) => (
                <a key={i} href={href}
                  className="w-9 h-9 border border-[rgba(201,168,76,0.4)] flex items-center justify-center text-[var(--ka-sand)] opacity-60 hover:opacity-100 hover:border-[var(--ka-gold)] hover:text-[var(--ka-gold)] transition-all duration-300"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Shop */}
          <div className="space-y-6">
            <h3 className="section-label text-[var(--ka-gold-light)]">Shop</h3>
            <ul className="space-y-4">
              {[
                ['New Arrivals', '/shop'],
                ['Luxury Collection', '/shop?category=Luxury'],
                ['Streetwear', '/shop?category=Streetwear'],
                ['Minimalist', '/shop?category=Minimalist'],
                ['Accessories', '/shop?category=Accessories'],
              ].map(([label, path]) => (
                <li key={label}>
                  <Link
                    to={path}
                    className="text-sm text-[var(--ka-sand)] opacity-60 hover:opacity-100 hover:text-[var(--ka-gold)] transition-all ka-underline"
                    style={{ fontFamily: 'var(--font-body)' }}
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div className="space-y-6">
            <h3 className="section-label text-[var(--ka-gold-light)]">Help</h3>
            <ul className="space-y-4">
              {[
                ['Contact Us', '/contact'],
                ['Shipping & Returns', '#'],
                ['Size Guide', '#'],
                ['FAQ', '#'],
                ['Track My Order', '#'],
              ].map(([label, path]) => (
                <li key={label}>
                  <Link
                    to={path}
                    className="text-sm text-[var(--ka-sand)] opacity-60 hover:opacity-100 hover:text-[var(--ka-gold)] transition-all ka-underline"
                    style={{ fontFamily: 'var(--font-body)' }}
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-6">
            <h3 className="section-label text-[var(--ka-gold-light)]">Stay Inspired</h3>
            <p className="text-sm text-[var(--ka-sand)] opacity-60 leading-relaxed">
              Join the Kerenalexis circle for exclusive access to new collections and events.
            </p>
            <div className="flex flex-col gap-3">
              <input
                type="email"
                placeholder="Your email address"
                className="bg-transparent border border-[rgba(201,168,76,0.3)] text-[var(--ka-sand)] placeholder:text-[var(--ka-sand)] placeholder:opacity-30 px-4 py-3 text-sm focus:outline-none focus:border-[var(--ka-gold)] transition-colors w-full"
                style={{ fontFamily: 'var(--font-body)' }}
              />
              <button className="btn-ka py-3 px-6 bg-[var(--ka-gold)] text-[var(--ka-earth)] border border-[var(--ka-gold)] font-narrow font-semibold text-[11px] tracking-[0.2em]">
                <span>Join the Circle</span>
              </button>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <Mail className="h-4 w-4 text-[var(--ka-gold)] opacity-60" />
              <a href="mailto:concierge@kerenalexis.com" className="text-xs text-[var(--ka-sand)] opacity-50 hover:opacity-100 hover:text-[var(--ka-gold)] transition-all">
                concierge@kerenalexis.com
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-[rgba(201,168,76,0.2)] pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] text-[var(--ka-sand)] opacity-30 tracking-[0.3em] uppercase font-narrow">
            © {new Date().getFullYear()} Kerenalexis. All Rights Reserved.
          </p>
          <div className="flex gap-8 text-[10px] tracking-[0.25em] uppercase font-narrow">
            <a href="#" className="text-[var(--ka-sand)] opacity-30 hover:opacity-60 transition-opacity">Privacy Policy</a>
            <a href="#" className="text-[var(--ka-sand)] opacity-30 hover:opacity-60 transition-opacity">Terms of Service</a>
            <a href="#" className="text-[var(--ka-sand)] opacity-30 hover:opacity-60 transition-opacity">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
